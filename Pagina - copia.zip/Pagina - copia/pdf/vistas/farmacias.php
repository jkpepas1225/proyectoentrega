<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.png' , 10 ,8, 30 , 20,'png');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(250, 30, 'CEDESOFT - FARMACIAS', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE FARMACIAS', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);	
$pdf->Cell(15, 8, 'Codigo', 0);
$pdf->Cell(40, 8, 'Nombre', 0);
$pdf->Cell(25, 8, 'Direccion', 0);
$pdf->Cell(20, 8, 'Telefono', 0);
$pdf->Cell(25, 8, 'Ciudad', 0);
$pdf->Cell(40, 8, 'Administrador', 0);
$pdf->Cell(30, 8, 'Propietario', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT farma_codi, farma_nomb,farma_dir, farma_tel, c.ciu_nomb, a.admin_nomb, p.propi_nomb 
			FROM tb_farmasias as f 
				inner join tb_ciudades as c 
				ON f.ciu_codi = c.ciu_codi
				inner join tb_administradores as a
				ON f.admin_codi = a.admin_codi
				inner join tb_propietarios as p
				ON f.propi_codi = p.propi_codi
				");
$item = 0;
while($productos2 = mysql_fetch_array($productos)){
	$pdf->Cell(15, 8, $productos2['farma_codi'], 0);
	$pdf->Cell(40, 8,$productos2['farma_nomb'], 0);
	$pdf->Cell(25, 8,$productos2['farma_dir'], 0);
	$pdf->Cell(20, 8,$productos2['farma_tel'], 0);
	$pdf->Cell(25, 8,$productos2['ciu_nomb'], 0);
	$pdf->Cell(40, 8, $productos2['admin_nomb'], 0);
	$pdf->Cell(25, 8, $productos2['propi_nomb'], 0);
	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Output();
?>