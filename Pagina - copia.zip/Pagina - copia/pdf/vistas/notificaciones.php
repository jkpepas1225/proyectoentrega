<?php
require('../fpdf/fpdf.php');
require('../php/conexion.php');

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', '', 10);
$pdf->Image('../recursos/logo.png' , 10 ,8, 30 , 20,'png');
$pdf->Cell(18, 10, '', 0);
$pdf->Cell(250, 30, 'CEDESOFT - FARMACIAS', 0);
$pdf->SetFont('Arial', '', 9);
$pdf->Cell(50, 10, 'Fecha: '.date('d-m-Y').'', 0);
$pdf->Ln(15);
$pdf->SetFont('Arial', 'B', 11);
$pdf->Cell(70, 8, '', 0);
$pdf->Cell(100, 8, 'LISTADO DE NOTIFICACIONES', 0);
$pdf->Ln(23);
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(15, 8, 'Codigo', 0);
$pdf->Cell(100, 8, 'Descripcion', 0);
$pdf->Cell(20, 8, 'Fecha', 0);
$pdf->Cell(30, 8, 'Farmacia', 0);
$pdf->Cell(20, 8, 'Cliente', 0);
$pdf->Ln(8);
$pdf->SetFont('Arial', '', 8);
//CONSULTA
$productos = mysql_query("SELECT noti_codi, noti_nomb, noti_fecha, c.farma_nomb, a.cli_nomb
			FROM tb_notificaciones as f 
				inner join tb_farmasias as c 
				ON f.farma_codi = c.farma_codi
				inner join tb_clientes as a
				ON f.cli_codi = a.cli_codi
				");

while($productos2 = mysql_fetch_array($productos)){
	$pdf->Cell(15, 8, $productos2['noti_codi'], 0);
	$pdf->Cell(100, 8, $productos2['noti_nomb'], 0);
	$pdf->Cell(20, 8, $productos2['noti_fecha'] , 0);
	$pdf->Cell(30, 8, $productos2['farma_nomb'] , 0);
	$pdf->Cell(20, 8, $productos2['cli_nomb'] , 0);
	$pdf->Ln(8);
}
$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(114,8,'',0);
$pdf->Output();
?>