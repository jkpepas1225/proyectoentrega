<?php
	require_once('../modeloAbstractoDB.php');
	class Administradores extends ModeloAbstractoDB {
		private $admin_codi;
		private $admin_nomb;
		private $admin_edad;
		private $admin_genero;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getadmin_codi(){
			return $this->admin_codi;
		}

		public function getadmin_nomb(){
			return $this->admin_nomb;
		}

		public function getadmin_edad(){
			return $this->admin_edad;
		}

		public function getadmin_genero(){
			return $this->admin_genero;
		}
		
          

		public function consultar($admin_codi='') {
			if($admin_codi != ''):
				$this->query = "
				SELECT admin_codi, admin_nomb, admin_edad, admin_genero
				FROM tb_administradores
				WHERE admin_codi = '$admin_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT admin_codi, admin_nomb, admin_edad, admin_genero
			FROM tb_administradores as p ORDER BY p.admin_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('admin_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_administradores
				(admin_codi, admin_nomb, admin_edad, admin_genero)
				VALUES
				('$admin_codi', '$admin_nomb', '$admin_edad', '$admin_genero')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_administradores
			SET admin_nomb='$admin_nomb',
			admin_edad='$admin_edad',
			admin_genero='$admin_genero'
			WHERE admin_codi = '$admin_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($admin_codi='') {
			$this->query = "
			DELETE FROM tb_administradores
			WHERE admin_codi = '$admin_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>