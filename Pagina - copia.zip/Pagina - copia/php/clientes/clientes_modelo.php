<?php
	require_once('../modeloAbstractoDB.php');
	class Clientes extends ModeloAbstractoDB {
		private $cli_codi;
		private $cli_nomb;
		private $cli_edad;
		private $cli_genero;
		private $cli_tel;
		private $cli_email;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getcli_codi(){
			return $this->cli_codi;
		}

		public function getcli_nomb(){
			return $this->cli_nomb;
		}

		public function getcli_edad(){
			return $this->cli_edad;
		}

		public function getcli_genero(){
			return $this->cli_genero;
		}

		public function getcli_tel(){
			return $this->cli_tel;
		}

		public function getcli_email(){
			return $this->cli_email;
		}
		
          

		public function consultar($cli_codi='') {
			if($cli_codi != ''):
				$this->query = "
				SELECT cli_codi, cli_nomb, cli_edad, cli_genero, cli_tel, cli_email
				FROM tb_clientes
				WHERE cli_codi = '$cli_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT cli_codi, cli_nomb, cli_edad, cli_genero, cli_tel, cli_email
			FROM tb_clientes as p ORDER BY p.cli_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('cli_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_clientes
				(cli_codi, cli_nomb, cli_edad, cli_genero, cli_tel, cli_email)
				VALUES
				('$cli_codi', '$cli_nomb', '$cli_edad', '$cli_genero', '$cli_tel','$cli_email')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_clientes
			SET cli_nomb='$cli_nomb',
			cli_edad='$cli_edad',
			cli_genero='$cli_genero',
			cli_tel='$cli_tel',
			cli_email='$cli_email'
			WHERE cli_codi = '$cli_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($cli_codi='') {
			$this->query = "
			DELETE FROM tb_clientes
			WHERE cli_codi = '$cli_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>