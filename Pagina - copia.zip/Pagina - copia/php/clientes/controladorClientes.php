<?php
 
require_once 'clientes_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $clientes = new Clientes();
        $resultado = $clientes->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $clientes = new Clientes();
        $resultado = $clientes->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $clientes = new Clientes();
        $resultado = $clientes->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $clientes = new Clientes();
        $clientes->consultar($datos['codigo']);

        if($clientes->getcli_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $clientes->getcli_codi(),
                'clientes' => $clientes->getcli_nomb(),
                'edad' => $clientes->getcli_edad(),
                'genero' => $clientes->getcli_genero(),
                'telefono' => $clientes->getcli_tel(),
                'email' => $clientes->getcli_email(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $clientes = new Clientes();
        $listado = $clientes->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
