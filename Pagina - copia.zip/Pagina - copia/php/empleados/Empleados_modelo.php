<?php
	require_once('../modeloAbstractoDB.php');
	class Empleados extends ModeloAbstractoDB {
		private $emple_codi;
		private $emple_nomb;
		private $emple_ape;
		private $emple_edad;
		private $emple_genero;
		private $farma_codi;
		
		function __construct() {
			
		}
		
		public function getemple_codi(){
			return $this->emple_codi;
		}

		public function getemple_nomb(){
			return $this->emple_nomb;
		}

		public function getemple_ape(){
			return $this->emple_ape;
		}

		public function getemple_edad(){
			return $this->emple_edad;
		}
		public function getemple_genero(){
			return $this->emple_genero;
		}
		
		public function getfarma_codi(){
			return $this->farma_codi;
		}                

		public function consultar($emple_codi='') {
			if($emple_codi != ''):
				$this->query = "
				SELECT emple_codi, emple_nomb, emple_ape, emple_edad, emple_genero, farma_codi
				FROM tb_empleados
				WHERE emple_codi = '$emple_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT emple_codi, emple_nomb, emple_ape, emple_edad, emple_genero, p.farma_nomb
			FROM tb_empleados as m inner join tb_farmasias as p
			ON (m.farma_codi = p.farma_codi) ORDER BY m.emple_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		public function nuevo($datos=array()) {
			if(array_key_exists('emple_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_empleados
				(emple_codi, emple_nomb, emple_ape, emple_edad, emple_genero, farma_codi)
				VALUES
				('$emple_codi', '$emple_nomb', '$emple_ape', '$emple_edad', '$emple_genero', '$farma_codi')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_empleados
			SET emple_nomb='$emple_nomb',
			emple_ape='$emple_ape',
			emple_edad='$emple_edad',
			emple_genero='$emple_genero',
			farma_codi='$farma_codi'
			WHERE emple_codi = '$emple_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($emple_codi='') {
			$this->query = "
			DELETE FROM tb_empleados
			WHERE emple_codi = '$emple_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>