<?php
 
require_once 'Empleados_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $empleados = new Empleados();
		$resultado = $empleados->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $empleados = new Empleados();
		$resultado = $empleados->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$empleados = new Empleados();
		$resultado = $empleados->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $empleados = new Empleados();
        $empleados->consultar($datos['codigo']);

        if($empleados->getemple_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $empleados->getemple_codi(),
                'empleado' => $empleados->getemple_nomb(),
                'apellido' => $empleados->getemple_ape(),
                'edad' => $empleados->getemple_edad(),
                'genero' => $empleados->getemple_genero(),
                'farmacias' =>$empleados->getfarma_codi(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $empleados = new Empleados();
        $listado = $empleados->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
