<?php
 
require_once 'farmacias_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $farma = new farmacias();
		$resultado = $farma->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $farma = new farmacias();
		$resultado = $farma->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$farma = new farmacias();
		$resultado = $farma->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $farma = new farmacias();
        $farma->consultar($datos['codigo']);

        if($farma->getfarma_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $farma->getfarma_codi(),
                'farmacias' => $farma->getfarma_nomb(),
                'direccion' => $farma->getfarma_dir(),
                'telefono' => $farma->getfarma_tel(),
                'ciudad' =>$farma->getciu_codi(),
                'administrador' =>$farma->getadmin_codi(),
                'propietario' =>$farma->getpropi_codi(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $farma = new farmacias();
        $listado = $farma->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
