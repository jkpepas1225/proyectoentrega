<?php
	require_once('../modeloAbstractoDB.php');
	class Inventario extends ModeloAbstractoDB {
		private $inven_codi;
		private $produ_codi;
		private $stock;
		private $fecha;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getinven_codi(){
			return $this->inven_codi;
		}

		public function getprodu_codi(){
			return $this->produ_codi;
		}
		
		public function getstock(){
			return $this->stock;
		}        

		public function getfecha(){
			return $this->fecha;
		}           

		public function consultar($inven_codi='') {
			if($inven_codi != ''):
				$this->query = "
				SELECT inven_codi, produ_codi, stock, fecha
				FROM tb_inventario
				WHERE inven_codi = '$inven_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT inven_codi, p.produ_nomb, stock, fecha
			FROM tb_inventario as m inner join tb_productos as p
			ON (m.produ_codi = p.produ_codi) ORDER BY p.produ_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listadepartamento() {
			$this->query = "
			SELECT inven_codi, produ_codi, stock, fecha
			FROM tb_inventario as d order by inven_codi
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('inven_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_inventario
				(inven_codi, produ_codi, stock, fecha)
				VALUES
				('$inven_codi', '$produ_codi', '$stock', '$fecha')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_inventario
			SET produ_codi='$produ_codi',
			stock='$stock,
			fecha='$fecha
			WHERE inven_codi = '$inven_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($inven_codi='') {
			$this->query = "
			DELETE FROM tb_inventario
			WHERE inven_codi = '$inven_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>