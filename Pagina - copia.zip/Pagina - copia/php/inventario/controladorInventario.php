<?php
 
require_once 'Inventario_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $inventario = new Inventario();
		$resultado = $inventario->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $inventario = new Inventario();
		$resultado = $inventario->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$inventario = new Inventario();
		$resultado = $inventario->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $inventario = new Inventario();
        $inventario->consultar($datos['codigo']);

        if($inventario->getinven_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $inventario->getinven_codi(),
                'productos' => $inventario->getprodu_codi(),
                'stock' =>$inventario->getstock(),
                'fecha' =>$inventario->getfecha(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $inventario = new Inventario();
        $listado = $inventario->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
