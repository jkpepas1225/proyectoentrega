<?php
 
require_once 'proveedores_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $prov = new Proveedores();
        $resultado = $prov->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $prov = new Proveedores();
        $resultado = $prov->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $prov = new Proveedores();
        $resultado = $prov->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $prov = new Proveedores();
        $prov->consultar($datos['codigo']);

        if($prov->getprove_codi() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $prov->getprove_codi(),
                'proveedores' => $prov->getprove_nomb(),
                'direccion' => $prov->getprove_dir(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $prov = new Proveedores();
        $listado = $prov->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
