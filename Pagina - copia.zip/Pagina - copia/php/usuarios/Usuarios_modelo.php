<?php
	require_once('../modeloAbstractoDB.php');
	class Usuarios extends ModeloAbstractoDB {
		private $usu_codi;
		private $usu_nomb;
		private $usu_pass;
		private $rol_codi;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getusu_codi(){
			return $this->usu_codi;
		}

		public function getusu_nomb(){
			return $this->usu_nomb;
		}

		public function getusu_pass(){
			return $this->usu_pass;
		}
		
		public function getrol_codi(){
			return $this->rol_codi;
		}                

		public function consultar($usu_codi='') {
			if($usu_codi != ''):
				$this->query = "
				SELECT usu_codi, usu_nomb, usu_pass, rol_codi
				FROM tb_usuarios
				WHERE usu_codi = '$usu_codi'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT usu_codi, usu_nomb, usu_pass, p.rol_nomb
			FROM tb_usuarios as m inner join tb_roles as p
			ON (m.rol_codi = p.rol_codi) ORDER BY m.usu_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		public function listadepartamento() {
			$this->query = "
			SELECT usu_codi, usu_nomb, usu_pass, rol_codi
			FROM tb_usuarios as d order by usu_nomb
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('usu_codi', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_usuarios
				(usu_codi, usu_nomb, usu_pass, rol_codi)
				VALUES
				('$usu_codi', '$usu_nomb', '$usu_pass', '$rol_codi')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_usuarios
			SET usu_nomb='$usu_nomb',
			usu_pass='$usu_pass',
			rol_codi='$rol_codi'
			WHERE usu_codi = '$usu_codi'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($usu_codi='') {
			$this->query = "
			DELETE FROM tb_usuarios
			WHERE usu_codi = '$usu_codi'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>