<div id="nuevo-editar" class="hide">
		<!-- div para cargar el formulario para un nuevo departamento o editar un departamento -->
</div>

<div id="Ventas">
<div class="box-header">
    <i class="ion ion-clipboard"></i>
     <div width="100"><a target="_blank" href="pdf/vistas/ventayfacturacion.php" class="btn btn-info">PDF</a></div>
    <div class="pull-right box-tools">
    	<button class="btn btn-info btn-sm" id="nuevo"  data-toggle="tooltip" title="Nuevo Ventas"><i class="fa fa-plus" aria-hidden="true"></i></button> 
    	<button class="btn btn-info btn-sm btncerrar"  data-toggle="tooltip" title="Ocultar"><i class="fa fa-times"></i></button>

    </div><!-- /. tools -->
                  
</div><!-- /.box-header -->

<div class="box-body">

	<table id="tabla" class="table table-striped table-bordered table-hover" cellspacing="0" width="100%">
		<thead>
			<tr>
				<th>Codigo</th>
				<th>Cliente</th>
				<th>Producto</th>
				<th>Cantidad</th>
				<th>Fecha</th>
				<th>&nbsp;</th>
				<th>&nbsp;</th>
			</tr>
		</thead>
		<tbody>
		
		</tbody>

	</table>

</div><!-- /.box-body -->  
<script src="js/funcionesVentayfacturacion.js"></script>
</div>